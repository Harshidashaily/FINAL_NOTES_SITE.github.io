import java.util.*;
class BRIEF
{
    private String NAME;
    /*SINCE PRIVATE ACCESS MODIFIER CANNOT BE ACCESSED ANYWHERE OUTSIDE THE CLASS
     HENCE BY THE HELP OF THE GETTER AND SETTER WE CAN CONVERT IT INTO PUBLIC SO THAT IT CAN BE ACCESSIBLE OUTSIE THE CLASS.*/
    private int AGE;

    //SETTER METHOD
    public void setNAME(String NAME)
    {
        //IT IS STRING TYPE HENCE THE RETURN VALUE WILL BE STRING TYPE.
        this.NAME=NAME;
        //THIS OPERATOR IS USED TO REDUCE THE CONFLICT BY THE NAME OF THE PARAMETER PASSED AND THE ORIGINAL VALUE.
        //this.NAME IS REFERENCED TO THE PRIVATE ACCESS SPECIFIER'S NAME AND NAME IS REFERENCED TO THE NAME OF THE PARAMETER.
    }    
    public void setAGE(int AGE)
    {
        this.AGE=AGE;
    }

    //GETTER METHOD
    public String getNAME()
    {
        return NAME;
    }

    public int getAGE()
    {
        return AGE;
    }
}
public class GETTER_SETTER
{
    public static void main   (String[]   args)
    {
        BRIEF ABC=new BRIEF();
        ABC.setNAME("JAVA");
        ABC.setAGE(18);
        System.out.println(ABC.getNAME());
        System.out.println(ABC.getAGE());//BY THE HELP OF System.out.println, IT WILL PRINT THE RETURN VALUE OF THE PARTICULAR GETTER METHOS CONTENT..
    }
}