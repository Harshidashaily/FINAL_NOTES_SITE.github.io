import java.util.*;
//THERE ARE THREE IN-BUILT STREAMS IN JAVA 
//1.System.out=STANDARD OUTPUT STREAM
//2.System.in=STANDARD INPUT STREAM
//3.System.err=STANDARD ERROR STREAM 
public class STREAMS 
{
    public static void main   (String[]   args)
    {
        Scanner ABC=new Scanner(System.in);//THIS IS STANDARD INPUT STREAM.
        System.out.println("THIS IS STANDARD OUTPUT STREAM.");
        System.out.println("THIS IS STANDARD ERROR STREAM.");
    }
}
