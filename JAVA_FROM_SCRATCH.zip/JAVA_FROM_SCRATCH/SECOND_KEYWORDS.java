public class SECOND_KEYWORDS 
{
    public static void main   (String[]   args)    
    {
        int A=10;//USED TO STORE INTEGER VALUES.
        System.out.println(A);
        String B="JAVA FROM VERY SCRATCH";//USED TO STORE CHARACTER VALUES.
        System.out.println(B);

        //THE FLOAT STORES DECIMAL VALUES.
        //THE SPECIFICATION OF THE LETTER f AFTER GIVING THE VALUES BECAUSE TO SPECIFY THE FLOAT VALUE.
        //BECAUSE WITHOUT SPECIFICATION JAVA COMPILER THINKS THAT THE GIVEN DECIMAL VALUE IS OF DOUBLE TYPE AND SPECIFIES MORE MEMORY SPACE.
        //DOUBLE IS DOMINANT OVER FLOAT WITHOUT SPECIFICATION OF THE CHARACTER f OR F AT THE LAST OF THE NUMBER.
        float C=12.34f;
        System.out.println(C);

        double E=12.34;
        System.out.println(E);


        //HERE INTERGER VALUE IS DOMINANT OVER THE LONG HENCE, SPECIFICATION OF THE LETTER l OR L.
        //IF WE REQUIRE MORE MEMORY SPACE THEN THE LONG SHOULD BE SPECIFIED TO STORE THE INTEGER.
        long D=17890l;
        System.out.println(D);
        
        int F=109384;
        System.out.println(F);
    }
}
