//JAVA STRING CONCATENATION.
public class FOUR_CONCATENATION 
{
    public static void main   (String[]   args)
    {
        //CONCATEATION IS A TERM IN JAVA TO JOIN DIFFERENT STRING WORDS TOGETHER.
        //THERE ARE VARIOUS METHOD FOR THE CONCATENATION OF STRING IN JAVA.
        //SOME OF THEM ARE AS FOLLOWS=
        //1.BY USING + OPERATOR 
        String S1="JAVA";
        String S2="COURSE";
        String S3=S1+"  "+S2;
        System.out.println("CONCATENATION NY USING + OPERATOR IS AS FOLLOWS="+S3);

        //2.BY USING CONCAT METHOD
        String A="HEY!";
        String B="JAVA";
        String C=A.concat(B);//SYNTAX= string1.concat(string2);
        System.out.println("CONCATENATION BY USING CONCAT METHOD IS AS FOLLOWS="+C);


        //3.BY USING STRING BUILDER CLASS AND APPEND METHOD.
        StringBuilder ABC=new StringBuilder("HELLO");
        StringBuilder BCA=new StringBuilder("   WORLD!");
        StringBuilder CAB=ABC.append(BCA);
        System.out.println("THE VALUE OF STRING CONCATENATION BY STRING BUILDER IS="+CAB);
    }    
}
