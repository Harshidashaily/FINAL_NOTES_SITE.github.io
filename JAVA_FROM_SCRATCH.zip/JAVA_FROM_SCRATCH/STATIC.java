//STATIC VARIABLE= THE VALUE ONCE ASSIGNED CANNOT BE CHANGED. STATIC ITSELF MEANS ONE.
//STATIC MTHOD= IT IS USED SO THAT INSTANTIZATION OF THE OBJECT CANNOT BE DONE ,THE METHOD CAN BE CALLED DIRECTLY.
public class STATIC 
{
    public static void FOO()//STATIC METHOD
    {
        System.out.println("THIS IS A JAVA CODE");
    }  
    public static void FOO(float A)
    {
        System.out.println("THE PRICE OF ONE DOZEN OF BANANA IS="+A);
    }
    public static void FOO(float B,int C)
    {
        System.out.println("THE PRICE OF ONE KILOGRAM OF APPLE IS="+B);
        System.out.println("THE AGE OF THE SHOPKEEPER IS="+C);
    }
    public static void main   (String[]   args)
    {
        FOO();//DIRECT CALLING WITHOUT THE INSTANTIZATION OF THE OBJECT.
        FOO(19.45f);
        FOO(87.78f,24);
        int A=10;
        System.out.println("THE VALUE OF A IS="+A);//WILL GIVE THE VALUE OF A=10.
        //static int A=20;//WILL THROW ERROR BECAUSE A IS HAVING STATIC VALUE WHICH CANNOT BE CHANGED.
        // System.out.println(A);
    }
}
