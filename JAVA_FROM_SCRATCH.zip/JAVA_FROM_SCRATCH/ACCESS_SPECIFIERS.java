import java.util.*;
//ACCESS-SPECIFIER=IT IS A CONCEPT IN PROGRAMMING LANGUAGE TO RESERVE THE ACCESSIBIILITY IN DIFFERENT TYPES.
//THERE ARE FOUR KINDS OF ACCESS-MODIFIERS
//1.PRIVATE=IT IS A ACCESS MODIFIER WHICH IS ACCESSIBLE ONLY WITHIN THE CLASS OF THE PARTICULAR PROGRAM IN WHICH IT HAS BEEN DECLEARED.
//2. PROTECTED=IT HAS BEEN ACCESSIBLE IN THE WHOLE PROGRAM BUT NOT OUTSIDE THAT PROGRAM OR FILE.
//3.DEFAULT=IF WE DONOT SPECIFY ANY ACCESS MODIFIER THEN
//4.PUBLIC= IT IS ACCESSIBLE EVERYWHERE IN THE PARTICULAR IDE.
class ONE 
{
    int SALARY;
    private String NAME;
    public void setSALARY(int SALARY)
    {
        this.SALARY=SALARY;
    }
    public void setNAME(String NAME)
    {
        this.NAME=NAME;
    }
    public int getSALARY()
    {
        return SALARY;
    }
    public String getNAME()
    {
        return NAME;
    }
}
public class ACCESS_SPECIFIERS 
{
    public static void main   (String[]   args)
    {
        ONE ABC=new ONE();
        ABC.setSALARY(198463);
        ABC.setNAME("JAVA");
        System.out.println(ABC.getSALARY());
        System.out.println(ABC.getNAME());
    }
}
