import java.util.*;
class BASE1
{
    BASE1(int A)
    {
        System.out.println("I AM THE CONSTRUCTOR OF THE BASE CLASS AND MY VALUE IS="+A);
    }
}
class DERIEVED1 extends BASE1 
{
    DERIEVED1(int B)
    {
        super(87);//USED TO GIVE THE VALUE TO THE PARAMETER OF THE METHOD OR CONSTRUCTOR OF THE BASE CLASS WITHIN THE METHOD OR CONSTRUCTOR OF THE DERIEVED CLASS.
        System.out.println("I AM THE CONTRUCTOR OF THE DERIEVED CLASS AND THE VALUE IS="+B);
    }
}
public class SUPER 
{
    public static void main   (String[]   args)
    {
        DERIEVED1 ABC=new DERIEVED1(78);
    }
}
