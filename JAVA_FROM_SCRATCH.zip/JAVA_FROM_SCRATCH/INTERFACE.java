//INTERFACE= ALL THE METHODS OF INTERFACE ARE ABSTRACT TYPE.
//SINCE, MULTIPLE INHERITANCE IS NOT POSSIBLE IN JAVA BUT IT IS POSSIBLE USING INTERFACE IN JAVA.
//THE KEYWORD USED TO INHERIT THE PROPERTIES AND CHARACTERISTICS OF THE BASE CLASS INTO THE DERIEVED CLASS IS implements.
interface  BASE1 
{
    public void ONE();
}
interface BASE2
{
    public void TWO();
}

class DERIEVED1 implements BASE1,BASE2
{
    public void ONE()
    {
        System.out.println("THIS IS THE FIRST METHOD OF THE BASE CLASS.");
    }
    public void TWO()
    {
        System.out.println("THIS IS THE METHOD OF SECOND BASE CLASS.");
    }
}
public class INTERFACE 
{
    public static void main   (String[]   args)
    {
        DERIEVED1 ABC=new DERIEVED1();
        ABC.ONE();
        ABC.TWO();
    }
}
