//A CONSTRUCTOR GETS INVOKED AUTOMATICALLY WHEN THE OBJECT OF THE CLASS GETS INSTANTIZED.
//A CONSTRUCTOR IS NOT HAVING ANY RETURN-TYPE.
//A CONSTRUCTOR IS HAVING SAME NAME AS THAT OF THE CLASS IN WHICH IT RESIDES.

class ONE
{
    ONE()//CONSTRUCTOR WITHOUT ANY PARAMETER.
    {
        System.out.println("I AM A CONSTRAUCTOR OF THE CLASS WITH NO PARAMETER.");
    }
    ONE(int AGE)
    {
        System.out.println("THE AGE OF RAM IS="+AGE);
    }
    ONE(String NAME)
    {
        System.out.println("NAME OF RAM'S WIFE IS="+NAME);
    }
}
public class CONSTRUCTORS 
{
    public static void main   (String[]   args)
    {
        //CONSTRUCTORS ARE ALSO DIFFERENTIATED ON THE BASIS AND TYPE OF PARAMETERS PASSED IN IT.
        ONE AND=new ONE();
        ONE NDA=new ONE("JAVA");
        ONE DAN=new ONE(18);
    }    
}
