public class THREE_SIZE
{
    public static void main   (String[]   args)
    {
        int A=1234;
        System.out.println("THE VALUE OF A IS="+A);
        

        float B=23.45f;
        System.out.println("THE DECIMAL VALUE OF B IS="+B);
        System.out.println("THE INTEGER VALUE OF B IS="+(int)B);//THIS CONCEPT IS TERMED AS TYPECASTING WHICH MEANS CHANGING FROM ONE FORM TO ANOTHER.
        
        int C=97;
        System.out.println("THE VALUE OF A="+C);//OUTPUT=97
        System.out.println("THE VALUE OF A="+(float)C);//DUR TO TYPECASTING OUTPUT=97.0.

        //NOTE= WE CANNOT CHANGE THE STRING VALUE TO ANY NUMERIC FORM BUT IN NUMERIC FORM WE CAN PERFORM THE TYPECASTING ANYWAY.
    }   
}
